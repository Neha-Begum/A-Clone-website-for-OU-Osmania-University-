from django.shortcuts import render
from . models import Result, Mark

def index(request):
    list_of_results = Result.objects.all()
    return render(request,'index.html',{'list_of_results':list_of_results})

def marks(request):
    return render(request,'result.html')

def validate(request):
    htnumber = request.POST['hallticket']
    stmarks = Mark.objects.get(htno=htnumber)
    return render(request,'marks.html',{'stmarks':stmarks})